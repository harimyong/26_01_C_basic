#include <stdio.h>
int main() {
    int i = 1;
    while (i <= 5) {
        printf("%d ", i);
        // 증감식을 빼먹으면 무한 루프에 빠짐
        i++;
    }
    return 0;
}