#include <stdio.h>
int main() {
    for (int i = 1; i <= 10; i++) {
        if (i == 5){
            break;
        }
        printf("%d ", i); // 결과: 1 2 3 4
    }
    return 0;
}