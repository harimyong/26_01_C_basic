#include <stdio.h>
int main() {
    // 예시: 1부터 5까지 출력하기
    for (int i = 1; i <= 5; i++) { 
        printf("%d ", i);
    }
    return 0;
}