#include <stdio.h>
int main() {
    for (int i = 1; i <= 5; i++) { 
        if (i == 3) {
            continue;
        }
        printf("%d ", i); // 결과: 1 2 4 5
    }
    return 0;
}