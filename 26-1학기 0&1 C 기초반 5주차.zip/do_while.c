#include <stdio.h>
int main() {
    int i=5;
    do {
        printf("%d ",i--);
    } while (i != 1);
    return 0;
}