#include <stdio.h>

void hello(void) {
    printf("안녕하세요! 반환할 값이 없는 함수입니다.\n");
    // return; <- 값을 돌려주지 않고 여기서 종료한다는 뜻 (생략 가능)
}

int main() {
    hello(); // 함수 호출
    return 0;
}