#include <stdio.h>

void printTotal(int a,int b) { 
    printf("a + b = %d\n",a+b);
}

int main() {
    int a=3, b=3;
    printTotal(a,b);
    return 0;
}