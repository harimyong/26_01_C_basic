#include <stdio.h>

int factorial(int n) {
    if (n == 0){
        return 1;
    }
    return n * factorial(n - 1);
}

int main() {
    int n = 4; 
    printf("%d!의 결과는 %d입니다.\n", n, factorial(n));
    // 결과: 4!의 결과는 24입니다.
    return 0;
}