#include <stdio.h>

int sum(int a, int b) {
    return a + b;
}

int main() {
    int total = sum(5, 3);
    printf("합계 : %d\n", total); 
    return 0;
}