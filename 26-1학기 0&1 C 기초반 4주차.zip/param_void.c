#include <stdio.h>

int getTotal(void){
    int a = 10, b = 5;
    return a + b;
}

int main() {
    int total = getTotal(); 
    printf("Total : %d",total);
    return 0;
}