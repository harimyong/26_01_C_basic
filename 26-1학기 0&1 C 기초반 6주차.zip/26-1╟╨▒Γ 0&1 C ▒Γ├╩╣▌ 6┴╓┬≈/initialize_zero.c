#include <stdio.h>

int main(){
    int nums[10] = { 0, };
    printf("%d\n", nums[0]);
    printf("%d\n", nums[3]);
    printf("%d\n", nums[6]);
    printf("%d\n", nums[9]);
    
    return 0;
}