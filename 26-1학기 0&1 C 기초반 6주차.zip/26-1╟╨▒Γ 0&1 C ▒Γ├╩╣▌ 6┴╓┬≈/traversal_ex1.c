#include <stdio.h>

int main() {
    int scores[5] = {85, 92, 78, 95, 88};

    int max = scores[0];
    
    for (int i = 1; i < 5; i++) { 
        if (scores[i] > max) {
            max = scores[i];
        }
    }

    printf("최고 점수는 %d점입니다.\n", max);
    return 0;
}