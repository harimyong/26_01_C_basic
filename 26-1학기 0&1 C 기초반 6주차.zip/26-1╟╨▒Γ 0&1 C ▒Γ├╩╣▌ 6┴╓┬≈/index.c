#include <stdio.h>

int main() {

    int arr[5] = {1, 3, 7, 4, 10};
    printf("arr[0] : %d\n",arr[0]); 
    printf("arr[1] : %d\n",arr[1]); 
    printf("arr[3] : %d\n",arr[3]);

    return 0;
}