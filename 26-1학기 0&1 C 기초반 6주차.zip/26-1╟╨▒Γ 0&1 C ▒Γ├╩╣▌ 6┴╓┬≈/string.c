#include <stdio.h>

int main() {
    char word1[20];
    char word2[20];
    
    printf("두 단어를 입력하세요 (예: Hello C): ");
    
    // 배열 이름(word1, word2) 앞에 &를 붙이지 않음에 주의! 
    scanf("%s %s", word1, word2);
    
    printf("\n--- [입력 결과]---\n"); 
    printf("첫 번째 단어: %s\n", word1); 
    printf("두 번째 단어: %s\n", word2);

    // 널 문자가 진짜 들어있는지 확인 (단어의 끝)
    // "Hello"를 입력했다면 word1[5] 위치에 '\0'이 들어있음 
    printf("\n첫 번째 단어의 마지막 다음 칸(ASCII): %d\n", word1[5]);
    
    return 0;
}