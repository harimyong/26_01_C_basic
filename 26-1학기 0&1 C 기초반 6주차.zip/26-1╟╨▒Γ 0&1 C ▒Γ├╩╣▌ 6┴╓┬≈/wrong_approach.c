#include <stdio.h>

int main() {

    int arr[5] = {1, 3, 7, 4, 10}; 
    printf("arr[0]: %d\n",arr[0]); 
    printf("arr[1] : %d\n",arr[1]);
    printf(" 2! arr[5] : %d\n",arr[5]);
    
    return 0;
}