#include <stdio.h>

int main() {
    int scores[5] = {75, 88, 92, 60, 81};
    int count = 0;

    for (int i = 0; i < 5; i++) { 
        if (scores[i] >= 80) {
            count++;
        }
    }

    printf("80점 이상인 학생은 총 %d명입니다.\n", count);

    return 0;
}