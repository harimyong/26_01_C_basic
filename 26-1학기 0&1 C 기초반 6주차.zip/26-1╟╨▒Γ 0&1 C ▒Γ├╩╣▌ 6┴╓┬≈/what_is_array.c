#include <stdio.h>

int main() {
    int a1 = 1;
    int a2 = 3;
    int a3 = 7;
    int a4 = 4;
    int a5 = 10;
    int tot = a1 + a2 + a3 + a4 + a5; 
    printf("Total : %d\n", tot);

    int arr[5] = {1, 3, 7, 4, 10}; 
    tot = 0;
    for(int i = 0; i < 5; i++){ 
        tot = tot + arr[i]; 
    }
    printf("Total : %d", tot);
    
    return 0;
}