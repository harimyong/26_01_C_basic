#include <stdio.h>
int main() { 
    int arr[5];
    
    printf("5개의 숫자를 입력하세요:\n");
    for (int i = 0; i < 5; i++) {
        printf("%d번 인덱스에 값 입력 : ", i); 
        scanf("%d", &arr[i]);
    }

    printf("\n입력된 결과: ");
    for (int i = 0; i < 5; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}