#include <stdio.h>

int main() {
    int matrix[2][3] = { {1, 2, 3}, {4, 5, 6} };

    printf("2행 1열의 값: %d\n", matrix[1][0]);

    return 0;
}