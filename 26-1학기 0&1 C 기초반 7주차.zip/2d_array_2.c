#include <stdio.h>

int main() {
    int N = 3, M = 4;
    int numArr[3][4] = { 0, };
    int num = 11;
    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            numArr[i][j] = numArr[i][j] + num;
            num = num + 11;
        }
    }

    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            printf("(%d,%d) : %d | ", i, j, numArr[i][j]);
        }
        printf("\n");
    }

    return 0;
}