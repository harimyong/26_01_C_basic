#include <stdio.h>

int main() {
    int arr4D[2][2][2][2];
    int value = 1;

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            for (int k = 0; k < 2; k++) {
                for (int l = 0; l < 2; l++) {
                    arr4D[i][j][k][l] = value;
                    value = value + 1;
                }
            }
        }
    }

    printf("--- 4차원 배열 특정 값 확인 ---\n");
    printf("arr4D[1][1][1][1] = %d\n", arr4D[1][1][1][1]);

    return 0;
}