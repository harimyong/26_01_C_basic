#include <stdio.h>

int main() {

    // 기본적인 변수 선언
    int age;

    // 여러 단어를 사용하는 경우
    int user_age;

    // 언더바로 시작 (가능하지만 보통 권장되지 않음)
    int _tempValue;

    // 숫자를 포함 (숫자로 시작하지만 않으면 가능)
    int score1;

    // 대문자를 포함
    int HongGilDong;

    age = 20;
    user_age = 21;
    score1 = 100;

    return 0;
}