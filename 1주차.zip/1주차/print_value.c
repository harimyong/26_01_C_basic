#include <stdio.h>

int main(){
    // 변수 초기화
    int age = 20;

    // 변수 출력
    printf("%d", age);
    
    return 0;
}