#include <stdio.h>

int main() {

    // 변수 초기화
    int year = 2025;
    printf("원래 year 값 : %d\n", year);

    // 변수 입력
    printf("연도를 입력해주세요 : ");
    scanf("%d", &year);

    // 변수 출력
    printf("입력 후 : %d", year);

    return 0;
}