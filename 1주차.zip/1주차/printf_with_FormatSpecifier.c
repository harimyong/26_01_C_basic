#include <stdio.h>

int main() {
    int num = 7;
    double pi = 3.141592;

    // 예시 1: %nd를 활용한 우측 정렬 (최소 3자리 확보)
    printf("정수 출력: |%3d|\n", num);

    // 예시 2: %0nd를 활용한 빈 공간 '0'으로 채우기
    printf("0으로 채우기: |%03d|\n", num);

    // 예시 3: %.nf를 활용한 소수점 자릿수 조절
    printf("소수점 제어: %.2f\n", pi);

    return 0;
}