#include <stdio.h>

int main() {
    int year = 2026;
    double version = 1.0;

    // 예시 1: 변수값 출력과 소수점 제어
    printf("현재 연도는 %d년이며, 강의 버전은 %.1f입니다.\n", year, version);

    // 예시 2: 이스케이프 문자(\n, \t) 활용
    printf("과목명\t\t점수\n");
    printf("C프로그래밍\t%d점\n", 100);

    // 예시 3: 특수 기호 출력(\", \\)
    printf("파일 경로는 \"C:\\C_Project\"입니다.\n");

    return 0;
}